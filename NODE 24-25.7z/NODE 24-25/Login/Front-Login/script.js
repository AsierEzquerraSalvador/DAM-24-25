// Al enviar el formulario, se previene la recarga de la página y se ejecuta la función.
document.getElementById('loginForm').addEventListener('submit', async function(event) {
    event.preventDefault();  // Evita que la página se recargue al enviar el formulario
    
    // Obtener los valores de los campos de usuario y contraseña.
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        // Enviar los datos al servidor usando fetch (solicitud POST).
        const response = await fetch('http://localhost:3000/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'  // Indicamos que enviamos JSON
            },
            body: JSON.stringify({ username, password })  // Enviamos los datos como JSON
        });

        const data = await response.json();  // Convertir la respuesta en JSON

        // Si la respuesta es exitosa, mostramos un mensaje de éxito.
        if (response.ok) {
            alert('Login exitoso: ' + data.username);
        } else {
            // Si hay error, mostramos el mensaje de error.
            alert('Error: ' + data.message);
        }
    } catch (error) {
        // Si hay un problema con la solicitud, mostramos un error genérico.
        console.error('Error al enviar la solicitud:', error);
        alert('Hubo un problema al intentar iniciar sesión.');
    }
});
